package guifx;
import javafx.application.Application;
import src.Model.Hotel;

public class App {

    public static void main(String[] args) {
        Application.launch(StartWindow.class);
    }
}

